/**
 * 
 */
package com;

/**
 * @author SHWETHA
 *
 */
public class Myclass {

	public void MyMethod() {
		
		System.out.println("I am in my method");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello world");
		System.out.println("I am shwetha");
		
		Myclass m= new Myclass();
		m.MyMethod();
		
				
	}

}
